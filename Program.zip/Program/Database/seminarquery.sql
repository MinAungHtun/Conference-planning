Create table facilitator(Fac_ID int not null primary key, Fac_Name varchar(30), Ph_No varchar(10));
Create table Event_Holder(Eve_hold_ID int not null primary key, Eve_hold_Name varchar(30), Ph_No varchar(10));
Create table Event_(Event_ID int not null primary key, Event_Name varchar(30),  Dura varchar(10), Eve_hold_ID int, Fac_ID int, foreign key (Fac_ID) references facilitator (Fac_ID),Foreign key (Eve_hold_ID) references Event_Holder (Eve_hold_ID));
Create table Attendee(Attendee_ID int not null primary key, Attendee_Name varchar(30), Ph_No varchar(10));
Create table Talkshow(Talkshow_ID int not null primary key, Event_ID int, furniture_facilitated char(1), Technical_facilitated char(1), foreign key (Event_ID) references Event_(Event_ID));
Create table Presentation(Presentation_ID int not null primary key, Event_ID int, Technical_facilitated char (1), foreign key (Event_ID) references Event_(Event_ID));
Create table Exhibitor(Exhibitor_ID int not null primary key, StallID int, Eve_hold_ID int, Foreign key (StallID) references Stall(StallID), Foreign key (Eve_hold_ID) references Event_Holder (Eve_hold_ID) );
Create table Room(RoomID int not null primary key, Area varchar(5));
Create table Room_Accommodated_Event_Holder(RAEH_ID int not null primary key, extras_supplied char(1), RoomID int, Eve_hold_ID int, FOREIGN KEY (Eve_hold_ID) references Event_Holder(Eve_hold_ID), Foreign key (RoomID) references Room (RoomID));
Create table Stall(StallID int not null primary key, Area varchar(5));
Create table Participant(Part_ID int not null primary key, VIP char(1), Attendee_ID int, Foreign Key (Attendee_ID) references Attendee (Attendee_ID));
Create table Audience(Aud_ID int not null primary key, Supplies char(1), Attendee_ID int,Foreign Key (Attendee_ID) references Attendee (Attendee_ID));
Create table Privileged_accommodation(FDSA_ID int not null primary key, Event_ID int, Extras_supplied char (1), Foreign key (Event_ID) references Event_(Event_ID));
Create table Attendee_Event(Attendee_ID int,Event_ID int,Bookedorconfirmed char(1), primary key (Attendee_ID,Event_ID),foreign key (Event_ID) references Event_ (Event_ID), foreign key (Attendee_ID) references Attendee (Attendee_ID));

Insert into facilitator values (1,'Harris','0987653421'), (2,'George','0972635287'), (3,'Mike','0992643583');
Insert into Event_Holder values (1,'Jerul','0953446723'),(2,'Min','0954356733'),(3,'John','0986464354');
Insert into Event_ values (1,'Lets get motivated','9-12',1,1),(2,'Music','12-2',2,2),(3,'Yoga','5-6',1,1);
Insert into Attendee values (1,'Jim','094866832'),(2,'Hannah','0983791456'),(3,'Jasmine','04054345');
Insert into Talkshow values (1,1,'Y','Y'),(2,2,'Y','Y');
Insert into Presentation values (1,3,'Y');
Insert into Exhibitor values (1,1,1),(2,2,2),(3,3,3);
Insert into Room values(1,'2000'),(2,'5000'),(3,'4000');
Insert into Room_Accommodated_Event_Holder values (1,'Y',1,1),(2,'Y',1,2);
Insert into Stall values (1,'200'),(2,'300'),(3,'400');
Insert into Participant values (1,'Y',1);
Insert into Audience values (1,'Y',2),(2,'N',3)
Insert into Privileged_accommodation values (1,1,'D');
Insert into Attendee_Event values (1,1,'B'),(1,2,'C');



