﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Seminar
{
    public partial class Home : Form
    {
        public Home()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            axWindowsMediaPlayer1.close();
            Valid v = new Valid("f2");
            v.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            axWindowsMediaPlayer1.close();
            Valid v = new Valid("f3");
            v.Show();
            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            axWindowsMediaPlayer1.close();
            Valid v = new Valid("f4");
            v.Show();
            this.Hide();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            axWindowsMediaPlayer1.close();
            Valid v = new Valid("f5");
            v.Show();
            this.Hide();
        }

        private void Home_Load(object sender, EventArgs e)
        {
            axWindowsMediaPlayer1.uiMode = "none";
            axWindowsMediaPlayer1.windowlessVideo = true;
            /*axWindowsMediaPlayer1.fullScreen = true;add this in full screen mode if desired (only if the app is in full screen mode)*/
            axWindowsMediaPlayer1.URL = "Conan Visits E3 2014.mp4";
        }

        private void button5_Click(object sender, EventArgs e)
        {
            axWindowsMediaPlayer1.close();
            itinerary i = new itinerary();
            i.Show();
            this.Hide();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
