﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Seminar
{
    public partial class NF2 : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-RLAVHVG\MAT;Initial Catalog=Seminar;Integrated Security=True");
        int a,c;
		public NF2()
        {
            InitializeComponent();
            
        }

        private void NF2_Load(object sender, EventArgs e)
        {
            
            axWindowsMediaPlayer1.uiMode = "none";
            axWindowsMediaPlayer1.windowlessVideo = true;
            /*axWindowsMediaPlayer1.fullScreen = true;add this in full screen mode if desired (only if the app is in full screen mode)*/
            axWindowsMediaPlayer1.URL = "Conan Visits E3 2014.mp4";
            datag();
            data2g();
            data3g();
        }

        private void button1_Click(object sender, EventArgs e)
        {
			try
                {

                    con.Open();
                    String Query = "SELECT COUNT(*)from Event_ where Dura='"+textBox2.Text+"' and Fac_ID="+Convert.ToInt32(textBox4.Text)+" ;";
                    SqlCommand cmd = new SqlCommand(Query, con);
                    a= (int)cmd.ExecuteScalar();
                    con.Close();
					if(a==0)
					{
            try
            {
                con.Open();
                SqlCommand com = con.CreateCommand();
                com.CommandType = CommandType.Text;
                com.CommandText = "Insert into Event_ values("+Convert.ToInt32(textBox5.Text)+",'"+textBox1.Text+"','"+textBox2.Text+"',"+Convert.ToInt32(textBox3.Text)+","+Convert.ToInt32(textBox4.Text)+");";
                com.ExecuteNonQuery();
                MessageBox.Show("Inserted Successfully");
                con.Close();
                datag();
                checkint();
            }
            catch (Exception ie)
            {
                        con.Close();
                MessageBox.Show(ie.ToString());
            }
					}
					else
					{
                    con.Close();
                    MessageBox.Show("Facilitator is occupied. Sorry");
					}
				}
			catch (Exception ie)
                {
                con.Close();
                MessageBox.Show(ie.ToString());
                }
        }
        public void datag()
        {
            try
            {
                con.Open();
                SqlCommand com = con.CreateCommand();
                com.CommandType = CommandType.Text;
                com.CommandText = "select * from Event_;";
                com.ExecuteNonQuery();
                DataTable dt = new DataTable();
                SqlDataAdapter da = new SqlDataAdapter(com);
                da.Fill(dt);
                dataGridView1.DataSource = dt;
                con.Close();
            }
            catch (Exception ie)
            {
                con.Close();
                MessageBox.Show(ie.ToString());
            }
        }
        public void checkint()
        {
            con.Open();
            String Query = "SELECT COUNT(*)from Event_ where Dura='" + textBox2.Text + "' and Eve_hold_ID=" + Convert.ToInt32(textBox3.Text) + " ;";
            SqlCommand cmd = new SqlCommand(Query, con);
            c = (int)cmd.ExecuteScalar();
            con.Close();
        
            if (c>1)
            {
                con.Open();
                SqlCommand com = con.CreateCommand();
                com.CommandType = CommandType.Text;
                com.CommandText = "Delete from Event_ where Event_ID="+ Convert.ToInt32(textBox5.Text)+" ;";
                com.ExecuteNonQuery();
                MessageBox.Show("Schedule overlapped");
                con.Close();
                datag();
            }
        }
        public void data2g()
        {
            try
            {
                con.Open();
                SqlCommand com = con.CreateCommand();
                com.CommandType = CommandType.Text;
                com.CommandText = "select * from Event_Holder;";
                com.ExecuteNonQuery();
                DataTable dt = new DataTable();
                SqlDataAdapter da = new SqlDataAdapter(com);
                da.Fill(dt);
                dataGridView2.DataSource = dt;
                con.Close();
            }
            catch (Exception ie)
            {
                con.Close();
                MessageBox.Show(ie.ToString());
            }
        }
        public void data3g()
        {
            try
            {
                con.Open();
                SqlCommand com = con.CreateCommand();
                com.CommandType = CommandType.Text;
                com.CommandText = "select * from facilitator;";
                com.ExecuteNonQuery();
                DataTable dt = new DataTable();
                SqlDataAdapter da = new SqlDataAdapter(com);
                da.Fill(dt);
                dataGridView3.DataSource = dt;
                con.Close();
            }
            catch (Exception ie)
            {
                con.Close();
                MessageBox.Show(ie.ToString());
            }
        }
        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                SqlCommand com = con.CreateCommand();
                com.CommandType = CommandType.Text;
                com.CommandText = "Delete from Event_ where Event_ID= "+Convert.ToInt32(textBox5.Text)+";";
                com.ExecuteNonQuery();
                MessageBox.Show("Deleted Successsfully");
                con.Close();
                datag();
            }
            catch (Exception ie)
            {
                con.Close();
                MessageBox.Show(ie.ToString());
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
			try
            {
                con.Open();
                SqlCommand com = con.CreateCommand();
                com.CommandType = CommandType.Text;
                com.CommandText = "Update Event_ set "+textBox6.Text+"='"+textBox8.Text+"'where Event_ID= "+Convert.ToInt32(textBox7.Text)+";";
                com.ExecuteNonQuery();
                MessageBox.Show("Updated Successsfully");
                con.Close();
                datag();
            }
            catch (Exception ie)
            {
                con.Close();
                MessageBox.Show(ie.ToString());
            }
		}
        
        
        private void button5_Click(object sender, EventArgs e)
        {
            axWindowsMediaPlayer1.close();
            Home h = new Home();
            h.Show();
            this.Hide();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
