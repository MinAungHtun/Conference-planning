﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace Seminar
{
    public partial class NF3 : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-RLAVHVG\MAT;Initial Catalog=Seminar;Integrated Security=True");
        public NF3()
        {
            InitializeComponent();
        }

        private void NF3_Load(object sender, EventArgs e)
        {
            axWindowsMediaPlayer1.uiMode = "none";
            axWindowsMediaPlayer1.windowlessVideo = true;
            /*axWindowsMediaPlayer1.fullScreen = true;add this in full screen mode if desired (only if the app is in full screen mode)*/
            axWindowsMediaPlayer1.URL = "Conan Visits E3 2014.mp4";
            datag();
            data2g();
        }
        public void datag()
        {
            try
            {
                con.Open();
                SqlCommand com = con.CreateCommand();
                com.CommandType = CommandType.Text;
                com.CommandText = "select * from Room;";
                com.ExecuteNonQuery();
                DataTable dt = new DataTable();
                SqlDataAdapter da = new SqlDataAdapter(com);
                da.Fill(dt);
                dataGridView1.DataSource = dt;
                con.Close();
            }
            catch (Exception ie)
            {
                con.Close();
                MessageBox.Show(ie.ToString());
            }
        }
        public void data2g()
        {
            try
            {
                con.Open();
                SqlCommand com = con.CreateCommand();
                com.CommandType = CommandType.Text;
                com.CommandText = "select * from Stall;";
                com.ExecuteNonQuery();
                DataTable dt = new DataTable();
                SqlDataAdapter da = new SqlDataAdapter(com);
                da.Fill(dt);
                dataGridView2.DataSource = dt;
                con.Close();
            }
            catch (Exception ie)
            {
                con.Close();
                MessageBox.Show(ie.ToString());
            }
        }
        private void button4_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                SqlCommand com = con.CreateCommand();
                com.CommandType = CommandType.Text;
                com.CommandText = "Insert into Room values ("+Convert.ToInt32(textBox1.Text)+",'"+textBox2.Text+"')";
                com.ExecuteNonQuery();
                MessageBox.Show("Inserted Successfully");
                con.Close();
                datag();
            }
            catch (Exception ie)
            {
                con.Close();
                MessageBox.Show(ie.ToString());
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {

			try
            {
                con.Open();
                SqlCommand com = con.CreateCommand();
                com.CommandType = CommandType.Text;
                com.CommandText = "Update Room Set "+textBox6.Text+"='"+textBox8.Text+"'where RoomID= "+Convert.ToInt32(textBox7.Text)+";";
                com.ExecuteNonQuery();
                MessageBox.Show("Updated Successsfully");
                con.Close();
                datag();
            }
            catch (Exception ie)
            {
                con.Close();
                MessageBox.Show(ie.ToString());
            }        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                SqlCommand com = con.CreateCommand();
                com.CommandType = CommandType.Text;
                com.CommandText = "Delete from Room where RoomID="+Convert.ToInt32(textBox1.Text)+";";
                com.ExecuteNonQuery();
                MessageBox.Show("Deleted Successfully");
                con.Close();
                datag();
            }
            catch (Exception ie)
            {
                con.Close();
                MessageBox.Show(ie.ToString());
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            axWindowsMediaPlayer1.close();
            Home h = new Home();
            h.Show();
            this.Hide();
        }

        private void button4_Click_1(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                SqlCommand com = con.CreateCommand();
                com.CommandType = CommandType.Text;
                com.CommandText = "Insert into Stall values ("+Convert.ToInt32(textBox4.Text)+",'"+textBox5.Text+"');";
                com.ExecuteNonQuery();
                MessageBox.Show("Inserted Successfully");
                con.Close();
                data2g();
            }
            catch(Exception ie)
            {
                con.Close();
                MessageBox.Show(ie.ToString());
            }
        }
        private void axWindowsMediaPlayer1_Enter(object sender, EventArgs e)
        {

        }

        private void button5_Click_1(object sender, EventArgs e)
        {

            try
            {
                con.Open();
                SqlCommand com = con.CreateCommand();
                com.CommandType = CommandType.Text;
                com.CommandText = "Update Stall Set " + textBox9.Text + "='" + textBox11.Text + "'where StallID= " + Convert.ToInt32(textBox10.Text) + ";";
                com.ExecuteNonQuery();
                MessageBox.Show("Updated Successsfully");
                con.Close();
                data2g();
            }
            catch (Exception ie)
            {
                con.Close();
                MessageBox.Show(ie.ToString());
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                SqlCommand com = con.CreateCommand();
                com.CommandType = CommandType.Text;
                com.CommandText = "Delete from Stall where StallID="+Convert.ToInt32(textBox4.Text)+";";
                com.ExecuteNonQuery();
                MessageBox.Show("Deleted Successfully");
                con.Close();
                data2g();
            }
            catch (Exception ie)
            {
                con.Close();
                MessageBox.Show(ie.ToString());
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            axWindowsMediaPlayer1.close();
            Home h = new Home();
            h.Show();
            this.Hide();
        }
    }
}
