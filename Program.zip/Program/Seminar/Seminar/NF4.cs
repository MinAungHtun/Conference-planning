﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace Seminar
{
    public partial class NF4 : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-RLAVHVG\MAT;Initial Catalog=Seminar;Integrated Security=True");
        public NF4()
        {
            InitializeComponent();
        }

        private void NF4_Load(object sender, EventArgs e)
        {
            axWindowsMediaPlayer1.uiMode = "none";
            axWindowsMediaPlayer1.windowlessVideo = true;
            /*axWindowsMediaPlayer1.fullScreen = true;add this in full screen mode if desired (only if the app is in full screen mode)*/
            axWindowsMediaPlayer1.URL = "Conan Visits E3 2014.mp4";
			datag();
        }
		public void datag()
        {
            try
            {
                con.Open();
                SqlCommand com = con.CreateCommand();
                com.CommandType = CommandType.Text;
                com.CommandText = "select * from Attendee;";
                com.ExecuteNonQuery();
                DataTable dt = new DataTable();
                SqlDataAdapter da = new SqlDataAdapter(com);
                da.Fill(dt);
                dataGridView1.DataSource = dt;
                con.Close();
            }
            catch (Exception ie)
            {
                con.Close();
                MessageBox.Show(ie.ToString());
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            axWindowsMediaPlayer1.close();
            Home h = new Home();
            h.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                SqlCommand com = con.CreateCommand();
                com.CommandType = CommandType.Text;
                com.CommandText = "Insert into Attendee values ("+Convert.ToInt32(textBox1.Text)+",'"+textBox2.Text+"','"+textBox3.Text+"');";
                com.ExecuteNonQuery();
                MessageBox.Show("Inserted Successfully");
                con.Close();
                datag();
            }
            catch (Exception ie)
            {
                con.Close();
                MessageBox.Show(ie.ToString());
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
         try
            {
                con.Open();
                SqlCommand com = con.CreateCommand();
                com.CommandType = CommandType.Text;
                com.CommandText = "Update Attendee Set "+textBox6.Text+"='"+textBox8.Text+"'where Attendee_ID= "+Convert.ToInt32(textBox7.Text)+";";
                com.ExecuteNonQuery();
                MessageBox.Show("Updated Successsfully");
                con.Close();
                datag();
            }
            catch (Exception ie)
            {
                con.Close();
                MessageBox.Show(ie.ToString());
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                SqlCommand com = con.CreateCommand();
                com.CommandType = CommandType.Text;
                com.CommandText = "Delete from Attendee where Attendee_ID="+Convert.ToInt32(textBox1.Text)+";";
                com.ExecuteNonQuery();
                MessageBox.Show("Deleted Successfully");
                con.Close();
                datag();
            }
            catch (Exception ie)
            {
                con.Close();
                MessageBox.Show(ie.ToString());
            }
        }
    }
}
