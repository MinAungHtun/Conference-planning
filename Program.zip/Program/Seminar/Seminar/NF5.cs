﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Seminar
{
    public partial class NF5 : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-RLAVHVG\MAT;Initial Catalog=Seminar;Integrated Security=True");
        int a;
		string b;
		public NF5()
        {
            InitializeComponent();
        }

        private void NF5_Load(object sender, EventArgs e)
        {
            axWindowsMediaPlayer1.uiMode = "none";
            axWindowsMediaPlayer1.windowlessVideo = true;
            /*axWindowsMediaPlayer1.fullScreen = true;add this in full screen mode if desired (only if the app is in full screen mode)*/
            axWindowsMediaPlayer1.URL = "Conan Visits E3 2014.mp4";
            datag();
            data2g();
            data3g();
        }
        public void datag()
        {
            try
            {
                con.Open();
                SqlCommand com = con.CreateCommand();
                com.CommandType = CommandType.Text;
                com.CommandText = "select * from Attendee_Event;";
                com.ExecuteNonQuery();
                DataTable dt = new DataTable();
                SqlDataAdapter da = new SqlDataAdapter(com);
                da.Fill(dt);
                dataGridView1.DataSource = dt;
                con.Close();
            }
            catch (Exception ie)
            {
                con.Close();
                MessageBox.Show(ie.ToString());
            }
        }

        public void data2g()
        {
            try
            {
                con.Open();
                SqlCommand com = con.CreateCommand();
                com.CommandType = CommandType.Text;
                com.CommandText = "select * from Attendee;";
                com.ExecuteNonQuery();
                DataTable dt = new DataTable();
                SqlDataAdapter da = new SqlDataAdapter(com);
                da.Fill(dt);
                dataGridView2.DataSource = dt;
                con.Close();
            }
            catch (Exception ie)
            {
                con.Close();
                MessageBox.Show(ie.ToString());
            }
        }

        public void data3g()
        {
            try
            {
                con.Open();
                SqlCommand com = con.CreateCommand();
                com.CommandType = CommandType.Text;
                com.CommandText = "select * from Event_;";
                com.ExecuteNonQuery();
                DataTable dt = new DataTable();
                SqlDataAdapter da = new SqlDataAdapter(com);
                da.Fill(dt);
                dataGridView3.DataSource = dt;
                con.Close();
            }
            catch (Exception ie)
            {
                con.Close();
                MessageBox.Show(ie.ToString());
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            axWindowsMediaPlayer1.close();
            Home h = new Home();
            h.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
			try
			{
				con.Open();
                    String Query = "SELECT * from Event_ e where Event_ID="+Convert.ToInt32(textBox2.Text)+";";
                    SqlCommand cmd = new SqlCommand(Query, con);
                    SqlDataReader Dreader;
                Dreader = cmd.ExecuteReader();
                while (Dreader.Read())
                {
                    b= Dreader["Dura"].ToString();
                    
                }
                con.Close();
                    
			try
                {

                    con.Open();
                    String Que = "SELECT COUNT(*) from Attendee_Event ae, Event_ e where ae.Event_ID=e.Event_ID and ae.Attendee_ID="+Convert.ToInt32(textBox1.Text)+"and e.Dura='"+b+"';";
                    SqlCommand cm = new SqlCommand(Que, con);
                    a= (int)cm.ExecuteScalar();
                    con.Close();
					if(a == 0)
					{
            try
            {
                con.Open();
                SqlCommand com = con.CreateCommand();
                com.CommandType = CommandType.Text;
                com.CommandText = "Insert into Attendee_Event values ("+Convert.ToInt32(textBox1.Text)+","+Convert.ToInt32(textBox2.Text)+",'"+textBox3.Text+"');";
                com.ExecuteNonQuery();
                MessageBox.Show("Inserted Successfully");
                con.Close();
                datag();
            }
            catch (Exception ie)
            {
                            con.Close();
                            MessageBox.Show(ie.ToString());
            }
					}
					else 
					{
                        con.Close();
                        MessageBox.Show("Attendee is occupied.Sorry!");
					}
				}
				catch(Exception ie)
				{
                    con.Close();
                    MessageBox.Show(ie.ToString());
				}
			}
			catch(Exception ie)
				{
                con.Close();
                MessageBox.Show(ie.ToString());
				}
        }

        private void button2_Click(object sender, EventArgs e)
        {

    			try
            {
                con.Open();
                SqlCommand com = con.CreateCommand();
                com.CommandType = CommandType.Text;
                com.CommandText = "Update Attendee_Event set Bookedorconfirmed='"+textBox8.Text+"'where Attendee_ID= "+Convert.ToInt32(textBox7.Text)+" and Event_ID="+Convert.ToInt32(textBox4.Text)+";";
                com.ExecuteNonQuery();
                MessageBox.Show("Updated Successsfully");
                con.Close();
                datag();
            }
            catch (Exception ie)
            {
                con.Close();
                MessageBox.Show(ie.ToString());
            }    }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                SqlCommand com = con.CreateCommand();
                com.CommandType = CommandType.Text;
                com.CommandText = "Delete from Attendee_Event where Attendee_ID="+Convert.ToInt32(textBox1.Text)+"and Event_ID="+Convert.ToInt32(textBox2.Text)+";";
                com.ExecuteNonQuery();
                MessageBox.Show("Deleted Successfully");
                con.Close();
                datag();
            }
            catch (Exception ie)
            {
                con.Close();
                MessageBox.Show(ie.ToString());
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            axWindowsMediaPlayer1.close();
            Home h = new Home();
            h.Show();
            this.Hide();
        }
    }
}
