﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Seminar
{
    public partial class Valid : Form
    {
        string b;
        public Valid(string a)
        {
            InitializeComponent();
            b = a;
            MessageBox.Show("The password is 'incorrect'. The space is not tolerable.");
        }
        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "incorrect" && b == "f2")
            {
                NF2 f2 = new NF2();
                f2.Show();
                this.Hide();
            }
            else if (textBox1.Text == "incorrect" && b == "f3")
            {
                NF3 f3 = new NF3();
                f3.Show();
                this.Hide();
            }
            else if (textBox1.Text == "incorrect" && b == "f4")
            {
                NF4 f4 = new NF4();
                f4.Show();
                this.Hide();
            }
            else if (textBox1.Text == "incorrect" && b == "f5")
            {
                NF5 f5 = new NF5();
                f5.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Wrong Password");
            }
        }

        private void Valid_Load(object sender, EventArgs e)
        {
        }
    }
}
