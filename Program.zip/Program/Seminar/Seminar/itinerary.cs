﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Seminar
{
    public partial class itinerary : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-RLAVHVG\MAT;Initial Catalog=Seminar;Integrated Security=True");
        public itinerary()
        {
            InitializeComponent();
        }

        private void itinerary_Load(object sender, EventArgs e)
        {
            axWindowsMediaPlayer1.uiMode = "none";
            axWindowsMediaPlayer1.windowlessVideo = true;
            /*axWindowsMediaPlayer1.fullScreen = true;add this in full screen mode if desired (only if the app is in full screen mode)*/
            axWindowsMediaPlayer1.URL = "Conan Visits E3 2014.mp4";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                SqlCommand com = con.CreateCommand();
                com.CommandType = CommandType.Text;
                com.CommandText = "Select a.Attendee_Name, e.Event_Name, e.Dura from Attendee a, Event_ e, Attendee_Event ae where a.Attendee_ID=ae.Attendee_ID and ae.Event_ID=e.Event_ID and a.Attendee_ID="+Convert.ToInt32(textBox1.Text)+";";
                com.ExecuteNonQuery();
                DataTable dt = new DataTable();
                SqlDataAdapter da = new SqlDataAdapter(com);
                da.Fill(dt);
                dataGridView1.DataSource = dt;
                con.Close();
            }
            catch (Exception ie)
            {
                MessageBox.Show(ie.ToString());
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                SqlCommand com = con.CreateCommand();
                com.CommandType = CommandType.Text;
                com.CommandText = "select e.Event_Name, er.Eve_hold_Name, e.Dura, r.RoomID from Room r, Room_Accommodated_Event_Holder ra, Event_Holder er, Event_ e where r.RoomID=ra.RoomID and ra.Eve_hold_ID=er.Eve_hold_ID and er.Eve_hold_ID=e.Eve_hold_ID and r.RoomID="+Convert.ToInt32(textBox2.Text)+";";
                com.ExecuteNonQuery();
                DataTable dt = new DataTable();
                SqlDataAdapter da = new SqlDataAdapter(com);
                da.Fill(dt);
                dataGridView1.DataSource = dt;
                con.Close();
            }
            catch (Exception ie)
            {
                MessageBox.Show(ie.ToString());
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                SqlCommand com = con.CreateCommand();
                com.CommandType = CommandType.Text;
                com.CommandText = "select s.StallID, eh.Eve_hold_Name from Stall s, Exhibitor e, Event_Holder eh where s.StallID=e.StallID and e.Eve_hold_ID=eh.Eve_hold_ID and s.StallID=" + Convert.ToInt32(textBox4.Text)+ ";";
                com.ExecuteNonQuery();
                DataTable dt = new DataTable();
                SqlDataAdapter da = new SqlDataAdapter(com);
                da.Fill(dt);
                dataGridView1.DataSource = dt;
                con.Close();
            }
            catch (Exception ie)
            {
                MessageBox.Show(ie.ToString());
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                SqlCommand com = con.CreateCommand();
                com.CommandType = CommandType.Text;
                com.CommandText = "select e.Event_Name , e.Dura, f.Fac_Name, a.Attendee_Name from Event_ e, Facilitator f, Attendee_Event ae, Attendee a where f.Fac_ID=e.Fac_ID and e.Event_ID=ae.Event_ID and ae.Attendee_ID= a.Attendee_ID and e.Event_ID=" + Convert.ToInt32(textBox3.Text)+ ";";
                com.ExecuteNonQuery();
                DataTable dt = new DataTable();
                SqlDataAdapter da = new SqlDataAdapter(com);
                da.Fill(dt);
                dataGridView1.DataSource = dt;
                con.Close();
            }
            catch (Exception ie)
            {
                MessageBox.Show(ie.ToString());
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {
            axWindowsMediaPlayer1.close();
            Home h = new Home();
            h.Show();
            this.Hide();
        }
    }
}
